﻿using System;

using System.Collections.Generic;



class Recipe

{

    public string Name { get; set; }

    public List<Ingredient> Ingredients { get; set; }

    public List<string> Steps { get; set; }



    public Recipe()

    {

        Ingredients = new List<Ingredient>();

        Steps = new List<string>();

    }



    public void AddIngredient(string name, string quantity, string unit, int calories, FoodGroup foodGroup)

    {

        Ingredients.Add(new Ingredient(name, quantity, unit, calories, foodGroup));

    }



    public void PrintRecipe()

    {

        Console.WriteLine($"Recipe: {Name}");



        Console.WriteLine("Ingredients:");

        foreach (var ingredient in Ingredients)

        {

            Console.WriteLine($"- {ingredient}");

        }



        Console.WriteLine("Steps:");

        for (int i = 0; i < Steps.Count; i++)

        {

            Console.WriteLine($"{i + 1}. {Steps[i]}");

        }

    }



    public int GetTotalCalories()

    {

        int totalCalories = 0;

        foreach (var ingredient in Ingredients)

        {

            totalCalories += ingredient.Calories;

        }

        return totalCalories;

    }

}



class Ingredient

{

    public string Name { get; set; }

    public string Quantity { get; set; }

    public string Unit { get; set; }

    public int Calories { get; set; }

    public FoodGroup FoodGroup { get; set; }



    public Ingredient(string name, string quantity, string unit, int calories, FoodGroup foodGroup)

    {

        Name = name;

        Quantity = quantity;

        Unit = unit;

        Calories = calories;

        FoodGroup = foodGroup;

    }



    public override string ToString()

    {

        return $"{Quantity} {Unit} {Name} ({Calories} calories, {FoodGroup})";

    }

}



enum FoodGroup

{

    Dairy,

    Meat,

    Vegetables,

    Fruits,

    Grains,

    Legumes

}



class RecipeManager

{

    private List<Recipe> recipes;



    public RecipeManager()

    {

        recipes = new List<Recipe>();

    }



    public void AddRecipe()

    {

        Console.Write("Enter the name of the recipe: ");

        string name = Console.ReadLine();



        Recipe recipe = new Recipe();

        recipe.Name = name;



        Console.Write("Enter the number of ingredients: ");

        int numIngredients = Convert.ToInt32(Console.ReadLine());



        for (int i = 0; i < numIngredients; i++)

        {

            Console.Write($"Enter the name of ingredient {i + 1}: ");

            string ingredientName = Console.ReadLine();

            Console.Write($"Enter the quantity of {ingredientName}: ");

            string quantity = Console.ReadLine();

            Console.Write($"Enter the unit of measurement for {quantity} {ingredientName}: ");

            string unit = Console.ReadLine();

            Console.Write($"Enter the number of calories for {ingredientName}: ");

            int calories = Convert.ToInt32(Console.ReadLine());

            Console.Write($"Enter the food group for {ingredientName} (Dairy, Meat, Vegetables, Fruits, Grains, Legumes): ");

            FoodGroup foodGroup = (FoodGroup)Enum.Parse(typeof(FoodGroup), Console.ReadLine(), true);



            recipe.AddIngredient(ingredientName, quantity, unit, calories, foodGroup);

        }



        Console.Write("Enter the number of steps: ");

        int numSteps = Convert.ToInt32(Console.ReadLine());



        for (int i = 0; i < numSteps; i++)

        {

            Console.Write($"Enter step {i + 1}: ");

            string step = Console.ReadLine();

            recipe.Steps.Add(step);

        }



        recipes.Add(recipe);

    }



    public void DisplayRecipes()

    {

        Console.WriteLine("Recipe List:");

        recipes.Sort((r1, r2) => r1.Name.CompareTo(r2.Name));

        foreach (var recipe in recipes)

        {

            Console.WriteLine(recipe.Name);

        }

    }



    public void DisplayRecipeByName(string recipeName)

    {

        Recipe recipe = recipes.Find(r => r.Name.Equals(recipeName, StringComparison.OrdinalIgnoreCase));

        if (recipe != null)

        {

            recipe.PrintRecipe();

            int totalCalories = recipe.GetTotalCalories();

            Console.WriteLine($"Total Calories: {totalCalories}");

            if (totalCalories > 300)

            {

                Console.WriteLine("Warning: This recipe exceeds 300 calories.");

            }

        }

        else

        {

            Console.WriteLine("Recipe not found.");

        }

    }

}



class Program

{

    static void Main(string[] args)

    {

        RecipeManager recipeManager = new RecipeManager();

        bool exit = false;



        while (!exit)

        {

            Console.WriteLine();

            Console.WriteLine("Recipe App");

            Console.WriteLine("----------");

            Console.WriteLine("1. Enter new recipe");

            Console.WriteLine("2. Display recipe list");

            Console.WriteLine("3. Display recipe by name");

            Console.WriteLine("4. Exit");

            Console.Write("Select an option: ");

            string input = Console.ReadLine();



            switch (input)

            {

                case "1":

                    recipeManager.AddRecipe();

                    break;

                case "2":

                    recipeManager.DisplayRecipes();

                    break;

                case "3":

                    Console.Write("Enter the name of the recipe: ");

                    string recipeName = Console.ReadLine();

                    recipeManager.DisplayRecipeByName(recipeName);

                    break;

                case "4":

                    exit = true;

                    break;

                default:

                    Console.WriteLine("Invalid option.");

                    break;

            }

        }

    }

}